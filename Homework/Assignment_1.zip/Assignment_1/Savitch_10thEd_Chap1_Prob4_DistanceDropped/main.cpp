/* Block Comments - Only one to exist for documentation purposes
 * 
 * File:   main.cpp
 * Author: Mike Ibrahim
 * Created on January 13, 2022, 11:12 PM
 * Purpose: Savitch Programming Problems
 *          Take in a time in seconds, and output how far it would drop
 */

//System Level Libraries
#include <iostream> //Input-Output Library
using namespace std;

//User Defined Libraries

//Global Constants, not Global Variables (will not use global variables in this course)
//These are recognized constants from the sciences
//Physics/Chemistry/Engineering and Conversions between 
//systems of units!

//Function Prototypes

//Execution beings here!
int main(int argc, char** argv) {
    //Initialize Random Seed once here!
    
    //Declare Variables
    const char ACCEL = 32;      //Constant acceleration of 32 feet per second due to gravity
    
    float dist;                 //The distance traveled (feet)
    
    short seconds;              //The time in seconds (seconds)
    
    //Initialize Variables
    cout << "Enter a time in seconds: ";
    cin >> seconds;
    
    dist = ((ACCEL) * (seconds * seconds)) / 2;
    
    //Map the inputs/known to the outputs
    
    cout << "The distance traveled in " << seconds << " seconds is: " << dist << " feet" << endl;
    
    //Display the outputs
    
    //Exit the program
    return 0;
}

