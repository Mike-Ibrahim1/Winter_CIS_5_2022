/* Block Comments - Only one to exist for documentation purposes
 * 
 * File:   main.cpp
 * Author: Mike Ibrahim
 * Created on January 11, 2022, 3:17 AM
 * Purpose: Homework Assignment 1
 *          Distance per Tank of Gas
 */

//System Level Libraries
#include <iostream> //Input-Output Library
#include <iomanip>  //Formatting Library
using namespace std;

//User Defined Libraries

//Global Constants, not Global Variables (will not use global variables in this course)
//These are recognized constants from the sciences
//Physics/Chemistry/Engineering and Conversions between 
//systems of units!

//Function Prototypes

//Execution beings here!
int main(int argc, char** argv) {
    //Initialize Random Seed once here!
    
    //Declare Variables
    char ggTank;                //Car's gallon gas tank (gallons)
    
    float mpgTown,              //Car's average MPG when driving in town (MPG)
          mpgHwy,               //Car's average MPG when driving on highway (MPG)
          disTwn,               //Distance on one tank of gas when driven in town (miles)
          disHwy;               //Distance on one tank of gas when driven on highway (miles)
    
    //Initialize Variables
    ggTank = 20;                //Car has a 20-gallon gas tank (gallons);
    mpgTown = 23.5;             //Miles per gallon when driven in town (MPG)
    mpgHwy = 28.9;              //Miles per gallon when driven on highway (MPG)
    
    //Map the inputs/known to the outputs
    disTwn = ggTank * mpgTown;
    disHwy = ggTank * mpgHwy;
    
    //Display the outputs
    cout << "Distance car can travel in town on one full tank:    " << setw(5) << disTwn << " miles" << endl;
    cout << "Distance car can travel on highway on one full tank: " << setw(5) << disHwy << " miles" <<  endl;
    //Exit the program
    return 0;
}

